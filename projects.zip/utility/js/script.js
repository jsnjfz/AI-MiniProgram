document.addEventListener('DOMContentLoaded', function() {
    const markdownInput = document.getElementById('markdown-input');
    const markdownPreview = document.getElementById('markdown-preview');
    const boldBtn = document.getElementById('bold-btn');
    const italicBtn = document.getElementById('italic-btn');
    const headingBtn = document.getElementById('heading-btn');
    const linkBtn = document.getElementById('link-btn');
    const imageBtn = document.getElementById('image-btn');
    const listBtn = document.getElementById('list-btn');
    const codeBtn = document.getElementById('code-btn');
    const quoteBtn = document.getElementById('quote-btn');
    const clearBtn = document.getElementById('clear-btn');
    const saveBtn = document.getElementById('save-btn');

    // 初始化编辑器
    function init() {
        // 尝试从本地存储加载内容
        const savedContent = localStorage.getItem('markdown-content');
        if (savedContent) {
            markdownInput.value = savedContent;
        }
        
        // 初始渲染预览
        renderMarkdown();
        
        // 设置事件监听器
        markdownInput.addEventListener('input', renderMarkdown);
        boldBtn.addEventListener('click', insertBold);
        italicBtn.addEventListener('click', insertItalic);
        headingBtn.addEventListener('click', insertHeading);
        linkBtn.addEventListener('click', insertLink);
        imageBtn.addEventListener('click', insertImage);
        listBtn.addEventListener('click', insertList);
        codeBtn.addEventListener('click', insertCode);
        quoteBtn.addEventListener('click', insertQuote);
        clearBtn.addEventListener('click', clearEditor);
        saveBtn.addEventListener('click', saveContent);
    }

    // 渲染Markdown为HTML
    function renderMarkdown() {
        const markdownText = markdownInput.value;
        // 使用marked库将Markdown转换为HTML
        const rawHtml = marked.parse(markdownText);
        // 使用DOMPurify清理HTML以防止XSS攻击
        const cleanHtml = DOMPurify.sanitize(rawHtml);
        markdownPreview.innerHTML = cleanHtml;
        
        // 保存到本地存储
        localStorage.setItem('markdown-content', markdownText);
    }

    // 在光标位置插入文本
    function insertTextAtCursor(text) {
        const start = markdownInput.selectionStart;
        const end = markdownInput.selectionEnd;
        const selectedText = markdownInput.value.substring(start, end);
        const beforeText = markdownInput.value.substring(0, start);
        const afterText = markdownInput.value.substring(end);
        
        markdownInput.value = beforeText + text.replace('$selection', selectedText) + afterText;
        markdownInput.focus();
        
        // 设置光标位置
        const cursorPosition = start + text.indexOf('$selection') + selectedText.length;
        if (text.includes('$selection')) {
            markdownInput.setSelectionRange(
                start + text.indexOf('$selection'),
                start + text.indexOf('$selection') + selectedText.length
            );
        } else {
            markdownInput.setSelectionRange(
                start + text.length,
                start + text.length
            );
        }
        
        renderMarkdown();
    }

    // 工具栏按钮功能
    function insertBold() {
        insertTextAtCursor('**$selection**');
    }

    function insertItalic() {
        insertTextAtCursor('*$selection*');
    }

    function insertHeading() {
        insertTextAtCursor('## $selection');
    }

    function insertLink() {
        if (markdownInput.selectionStart === markdownInput.selectionEnd) {
            insertTextAtCursor('[链接文本](https://example.com)');
        } else {
            insertTextAtCursor('[$selection](https://example.com)');
        }
    }

    function insertImage() {
        insertTextAtCursor('![图片描述](https://example.com/image.jpg)');
    }

    function insertList() {
        insertTextAtCursor('- 列表项1\n- 列表项2\n- 列表项3');
    }

    function insertCode() {
        const start = markdownInput.selectionStart;
        const end = markdownInput.selectionEnd;
        const selectedText = markdownInput.value.substring(start, end);
        
        if (selectedText.includes('\n')) {
            insertTextAtCursor('```\n$selection\n```');
        } else {
            insertTextAtCursor('`$selection`');
        }
    }

    function insertQuote() {
        insertTextAtCursor('> $selection');
    }

    function clearEditor() {
        if (confirm('确定要清空编辑器内容吗？')) {
            markdownInput.value = '';
            renderMarkdown();
        }
    }

    function saveContent() {
        // 创建一个Blob对象
        const blob = new Blob([markdownInput.value], {type: 'text/markdown'});
        const url = URL.createObjectURL(blob);
        
        // 创建一个下载链接
        const a = document.createElement('a');
        a.href = url;
        a.download = 'markdown-content.md';
        document.body.appendChild(a);
        a.click();
        
        // 清理
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 100);
        
        // 显示保存成功提示
        const saveNotification = document.createElement('div');
        saveNotification.textContent = '保存成功！';
        saveNotification.style.position = 'fixed';
        saveNotification.style.bottom = '20px';
        saveNotification.style.right = '20px';
        saveNotification.style.backgroundColor = 'var(--success-color)';
        saveNotification.style.color = 'white';
        saveNotification.style.padding = '10px 20px';
        saveNotification.style.borderRadius = '5px';
        saveNotification.style.zIndex = '1000';
        document.body.appendChild(saveNotification);
        
        setTimeout(() => {
            document.body.removeChild(saveNotification);
        }, 3000);
    }

    // 初始化编辑器
    init();
});
