document.addEventListener('DOMContentLoaded', function() {
    // 游戏变量
    let cards = [];
    let flippedCards = [];
    let matchedPairs = 0;
    let totalPairs = 0;
    let moves = 0;
    let score = 0;
    let gameStarted = false;
    let gameTimer;
    let seconds = 0;
    let difficulty = 'medium';
    let canFlip = true;
    
    // DOM 元素
    const gameBoard = document.getElementById('game-board');
    const startBtn = document.getElementById('start-btn');
    const restartBtn = document.getElementById('restart-btn');
    const difficultySelect = document.getElementById('difficulty-select');
    const timeDisplay = document.getElementById('time');
    const movesDisplay = document.getElementById('moves');
    const scoreDisplay = document.getElementById('score');
    const gameMessage = document.getElementById('game-message');
    const messageTitle = document.getElementById('message-title');
    const messageText = document.getElementById('message-text');
    const finalTimeDisplay = document.getElementById('final-time');
    const finalMovesDisplay = document.getElementById('final-moves');
    const finalScoreDisplay = document.getElementById('final-score');
    const playAgainBtn = document.getElementById('play-again-btn');
    
    // 卡片图标（使用 Font Awesome 图标）
    const cardIcons = [
        'fa-apple', 'fa-heart', 'fa-star', 'fa-bell', 
        'fa-bolt', 'fa-cloud', 'fa-moon', 'fa-sun',
        'fa-music', 'fa-camera', 'fa-car', 'fa-plane',
        'fa-gift', 'fa-leaf', 'fa-fire', 'fa-snowflake',
        'fa-pizza-slice', 'fa-coffee', 'fa-bicycle', 'fa-rocket',
        'fa-gamepad', 'fa-book', 'fa-cat', 'fa-dog'
    ];
    
    // 初始化游戏
    function init() {
        // 设置事件监听器
        startBtn.addEventListener('click', startGame);
        restartBtn.addEventListener('click', restartGame);
        difficultySelect.addEventListener('change', changeDifficulty);
        playAgainBtn.addEventListener('click', restartGame);
        
        // 初始状态
        restartBtn.disabled = true;
        difficultySelect.value = difficulty;
    }
    
    // 开始游戏
    function startGame() {
        gameStarted = true;
        startBtn.disabled = true;
        restartBtn.disabled = false;
        difficultySelect.disabled = true;
        
        // 重置游戏状态
        resetGameState();
        
        // 创建卡片
        createCards();
        
        // 开始计时
        startTimer();
    }
    
    // 重新开始游戏
    function restartGame() {
        // 停止计时器
        clearInterval(gameTimer);
        
        // 隐藏游戏结束消息
        gameMessage.classList.add('hidden');
        
        // 重新开始游戏
        startGame();
    }
    
    // 改变难度
    function changeDifficulty(e) {
        difficulty = e.target.value;
    }
    
    // 重置游戏状态
    function resetGameState() {
        cards = [];
        flippedCards = [];
        matchedPairs = 0;
        moves = 0;
        score = 0;
        seconds = 0;
        canFlip = true;
        
        // 清空游戏面板
        gameBoard.innerHTML = '';
        
        // 重置显示
        timeDisplay.textContent = '00:00';
        movesDisplay.textContent = '0';
        scoreDisplay.textContent = '0';
    }
    
    // 创建卡片
    function createCards() {
        // 根据难度设置游戏面板
        let rows, cols;
        switch(difficulty) {
            case 'easy':
                rows = 3;
                cols = 4;
                break;
            case 'medium':
                rows = 4;
                cols = 4;
                break;
            case 'hard':
                rows = 4;
                cols = 6;
                break;
            default:
                rows = 4;
                cols = 4;
        }
        
        // 设置游戏面板样式
        gameBoard.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
        
        // 计算需要的卡片对数
        totalPairs = (rows * cols) / 2;
        
        // 选择需要的图标
        const selectedIcons = cardIcons.slice(0, totalPairs);
        
        // 创建卡片对（每个图标两张卡片）
        let cardPairs = [];
        selectedIcons.forEach(icon => {
            cardPairs.push(
                createCardData(icon),
                createCardData(icon)
            );
        });
        
        // 洗牌
        cardPairs = shuffleArray(cardPairs);
        
        // 创建卡片元素并添加到游戏面板
        cardPairs.forEach((cardData, index) => {
            const card = createCardElement(cardData, index);
            gameBoard.appendChild(card);
            cards.push(card);
        });
    }
    
    // 创建卡片数据
    function createCardData(icon) {
        return {
            icon: icon,
            matched: false
        };
    }
    
    // 创建卡片元素
    function createCardElement(cardData, index) {
        const card = document.createElement('div');
        card.className = 'card';
        card.dataset.index = index;
        
        const cardInner = document.createElement('div');
        cardInner.className = 'card-inner';
        
        const cardFront = document.createElement('div');
        cardFront.className = 'card-front';
        
        const iconFront = document.createElement('i');
        iconFront.className = `fas ${cardData.icon} card-icon`;
        cardFront.appendChild(iconFront);
        
        const cardBack = document.createElement('div');
        cardBack.className = 'card-back';
        
        const iconBack = document.createElement('i');
        iconBack.className = 'fas fa-question card-back-icon';
        cardBack.appendChild(iconBack);
        
        cardInner.appendChild(cardFront);
        cardInner.appendChild(cardBack);
        card.appendChild(cardInner);
        
        // 添加点击事件
        card.addEventListener('click', () => flipCard(card, cardData));
        
        return card;
    }
    
    // 翻转卡片
    function flipCard(card, cardData) {
        // 如果游戏未开始、不能翻牌、已匹配或已翻转，则不执行操作
        if (!gameStarted || !canFlip || cardData.matched || flippedCards.includes(card)) {
            return;
        }
        
        // 翻转卡片
        card.classList.add('flipped');
        flippedCards.push(card);
        
        // 如果翻转了两张卡片，检查是否匹配
        if (flippedCards.length === 2) {
            moves++;
            movesDisplay.textContent = moves;
            
            // 暂时禁止翻牌
            canFlip = false;
            
            const card1Index = parseInt(flippedCards[0].dataset.index);
            const card2Index = parseInt(flippedCards[1].dataset.index);
            const card1Data = cardIcons[Math.floor(card1Index % totalPairs)];
            const card2Data = cardIcons[Math.floor(card2Index % totalPairs)];
            
            // 检查是否匹配
            if (card1Data === card2Data) {
                // 匹配成功
                setTimeout(() => {
                    flippedCards.forEach(card => {
                        card.style.opacity = '0.7';
                    });
                    
                    // 更新匹配状态
                    matchedPairs++;
                    
                    // 更新分数
                    updateScore(true);
                    
                    // 重置翻转状态
                    flippedCards = [];
                    canFlip = true;
                    
                    // 检查游戏是否结束
                    checkGameEnd();
                }, 500);
            } else {
                // 匹配失败
                setTimeout(() => {
                    flippedCards.forEach(card => {
                        card.classList.remove('flipped');
                    });
                    
                    // 更新分数
                    updateScore(false);
                    
                    // 重置翻转状态
                    flippedCards = [];
                    canFlip = true;
                }, 1000);
            }
        }
    }
    
    // 更新分数
    function updateScore(isMatch) {
        // 匹配成功加分，失败减分
        if (isMatch) {
            // 基础分 + 速度奖励
            const baseScore = 10;
            const speedBonus = Math.max(0, 5 - Math.floor(seconds / 10));
            score += baseScore + speedBonus;
        } else {
            // 失败扣分，但不低于0
            score = Math.max(0, score - 2);
        }
        
        scoreDisplay.textContent = score;
    }
    
    // 检查游戏是否结束
    function checkGameEnd() {
        if (matchedPairs === totalPairs) {
            // 停止计时器
            clearInterval(gameTimer);
            
            // 显示游戏结束消息
            setTimeout(() => {
                messageTitle.textContent = '恭喜！';
                messageText.textContent = '你成功完成了记忆翻牌挑战！';
                finalTimeDisplay.textContent = formatTime(seconds);
                finalMovesDisplay.textContent = moves;
                finalScoreDisplay.textContent = score;
                gameMessage.classList.remove('hidden');
            }, 500);
        }
    }
    
    // 开始计时器
    function startTimer() {
        clearInterval(gameTimer);
        seconds = 0;
        timeDisplay.textContent = '00:00';
        
        gameTimer = setInterval(() => {
            seconds++;
            timeDisplay.textContent = formatTime(seconds);
        }, 1000);
    }
    
    // 格式化时间
    function formatTime(totalSeconds) {
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // 洗牌函数（Fisher-Yates 算法）
    function shuffleArray(array) {
        const newArray = [...array];
        for (let i = newArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
        }
        return newArray;
    }
    
    // 初始化游戏
    init();
});
